// import img from "../../assets/home.png";
// function Vertical1() {
//   return (
    
//   );
// }

// export default Vertical1;
