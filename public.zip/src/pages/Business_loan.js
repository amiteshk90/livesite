import React, { useEffect } from "react";
import business_first from "../assets/business_first.png";
import Logo from "../assets/Logo.png";

const Business_loan = () => {
  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll("section");
      const navbar = document.querySelector("nav");
      const links = document.querySelectorAll("nav a");
      const applyButton = document.getElementById("apply-button");
      const logo = document.getElementById("navbar-logo");
      navbar.style.backgroundColor = "#DADADA";

      if (navbar && sections.length && links.length) {
        sections.forEach((section, index) => {
          const sectionTop = section.getBoundingClientRect().top;

          if (sectionTop <= 0 && sectionTop + section.offsetHeight > 0) {
            const colors = ["", "#DADADA", "#DADADA", "#DADADA"];
            navbar.style.backgroundColor = colors[index];

            if (index === 0) {
              // For the first section, retain original link color
              links.forEach((link) => (link.style.color = "black"));
              applyButton.style.backgroundColor = "#0057FF";
              navbar.style.backgroundColor = "#DADADA";
              applyButton.style.color = "white";
              logo.src = Logo;
            } else {
              // For all other sections, change link color to black
              links.forEach((link) => (link.style.color = "black"));
              applyButton.style.backgroundColor = "#0057FF";
              navbar.style.backgroundColor = "#DADADA";
              applyButton.style.color = "white";
              logo.src = Logo;
            }
          }
        });
      }
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  return (
    <>
      <section className="bg-Body-color py-24 px-14 flex">
        <div className="">
          <h1>Get Business Loans Approved within 24 Hours*</h1>
          <h2>Upto ₹ 1,00,000</h2>
          <button className="bg-btn-gradient text-white mx-auto md:mx-0 md:flex md:mt-0 items-center justify-center font-medium px-5 rounded-3xl p-2 mt-4">
            Apply Now
          </button>
          <p>Trusted by</p>
          <h2>Businesses in India</h2>
        </div>

        <div className="">
          <img src={business_first} />
        </div>
      </section>
      <div className="flex justify-around bg-blue-gradient">
        <p>Minimal Documentation</p>
        <div class="white-dot"></div>
        No Collateral Required
        <div class="white-dot"></div>
        Easy Disbursal
        <div class="white-dot"></div>
        Fully Online Loan Application
      </div>
    </>
  );
};

export default Business_loan;
