import React from 'react'

const Business_loan = () => {
  return (
    <div>Business_loan</div>
  )
}

export default Business_loan