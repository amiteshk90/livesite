import React from 'react'

const Personal_loan = () => {
  return (
    <div>Personal_loan</div>
  )
}

export default Personal_loan