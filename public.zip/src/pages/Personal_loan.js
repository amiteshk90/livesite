import React from 'react'
import banner1 from '../assets/first_sec_img.png'
import banner2 from '../assets/first_sec_phn.png'

const Personal_loan = () => {
  return (
    <section>
      <div className='container relative bg-banner-pattern bg-contain bg-no-repeat bg-Body-color py-24 px-14'>
        <div className='flex justify-between items-end'>
          <div className='flex-1 ml-12'>
            <h1 className='text-white text-7xl font-bold mb-20'>Borrow Smart,<br/> Dream Big</h1>
            <p className='text-black w-8/12'>Your Trusted Financial Companion. Access Quick and Secure Loans Tailored to Your Needs, Backed by Transparent Terms and Exceptional Service.</p>
          </div>
          <div className='flex-1'>
            <div className='flex items-baseline'>
              <img src={banner1} className='z-20' style={{marginRight: "-80px"}}/>
              <img src={banner2}/>
            </div>
              
          </div>
        </div>
      </div>
    </section>
  )
}

export default Personal_loan