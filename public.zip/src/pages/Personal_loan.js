import React, { useEffect, useRef, useState } from "react";
import banner1 from "../assets/bannerimg.png";
import img1 from "../assets/section_sec_img1.png";
import img2 from "../assets/section_sec_img2.png";
import { FaPlay } from "react-icons/fa";
import { useInView } from 'react-intersection-observer';

const Personal_loan = () => {
  const [showSecondImage, setShowSecondImage] = useState(false);
  const sectionRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect();
        if (rect.top <= 0) {
          setShowSecondImage(true);
        } else {
          setShowSecondImage(false);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  return (
    <>
      <section className="relative bg-banner-pattern bg-contain bg-no-repeat bg-Body-color py-24 px-14">
        <div className="container">
          <div className="flex justify-between items-end">
            <div className="flex-1">
              <h1 className="text-white text-4xl md:text-6xl lg:text-7xl font-bold mb-20">
                Borrow Smart,
                <br /> Dream Big
              </h1>
              <p className="text-black w-8/12">
                Your Trusted Financial Companion. Access Quick and Secure Loans
                Tailored to Your Needs, Backed by Transparent Terms and
                Exceptional Service.
              </p>
              <div className="flex items-center mt-4">
                <button className="bg-btn-gradient text-white mx-auto md:mx-0 md:flex md:mt-0 items-center justify-center font-medium px-5 rounded-3xl p-2 mt-4`">
                  Apply For Loan
                </button>
                <div className="flex pl-4 items-center">
                  <div
                    style={{ padding: "10px" }}
                    className="border-2 border-dotted border-blue-700 rounded-full"
                  >
                    <FaPlay style={{ color: "blue" }} />
                  </div>

                  <h1 className="pl-2 font-semibold text-xl md:text-xl lg:text-xl xl:text-xl">
                    WATCH DEMO
                  </h1>
                </div>
              </div>
            </div>
            <div className="flex-1">
              <div className="flex items-baseline">
                <img
                  src={banner1}
                  className="z-20 object-fill mb-4 md:mb-0 md:mr-4"
                  style={{ width: "100%" }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section ref={sectionRef} className="relative py-24 px-14 flex items-center">
      <div className="relative">
        <img
          src={img1}
          alt="First Image"
          className={`transition-opacity duration-1000 ease-in-out ${
            showSecondImage ? 'opacity-0' : 'opacity-100'
          }`}
        />
        <img
          src={img2}
          alt="Second Image"
          className={`absolute top-0 left-0 transition-opacity duration-1000 ease-in-out ${
            showSecondImage ? 'opacity-100' : 'opacity-0'
          }`}
        />
      </div>
    </section>
    </>
  );
};

export default Personal_loan;
